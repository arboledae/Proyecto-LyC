import java.io.*;

public class Main {
    public static void main(String[] args) {
        String rutaArchivo = "codigo.txt";

        System.out.println("=====================================");
        System.out.println("   ANALIZADOR LÉXICO OFICIAL   ");
        System.out.println("=====================================");

        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            AnalizadorLexico lexer = new AnalizadorLexico(br);
            int token;

            System.out.printf("%-20s | %-25s | %-6s | %-6s%n", "TOKEN", "LEXEMA", "LÍNEA", "COLUMNA");
            System.out.println("-----------------------------------------------------------------------------");

            while ((token = lexer.yylex()) != -1) {
                String nombreToken = obtenerNombreToken(token);
                String lexema = lexer.yytext();
                int linea = lexer.getLine();
                int columna = lexer.getColumn();

                if (token == AnalizadorLexico.TOKEN_ERROR) {
                    System.out.printf("[ERROR] %-12s | %-25s | %-6d | %-6d%n", nombreToken, lexema, linea, columna);
                } else {
                    System.out.printf("%-20s | %-25s | %-6d | %-6d%n", nombreToken, lexema, linea, columna);
                }
            }
            System.out.println("-----------------------------------------------------------------------------");
            System.out.println("PROCESO TERMINADO.");

        } catch (FileNotFoundException e) {
            System.err.println("Error: Falta el archivo '" + rutaArchivo + "'");
        } catch (IOException e) {
            System.err.println("Error de lectura crítico: " + e.getMessage());
        }
    }

    private static String obtenerNombreToken(int token) {
        switch (token) {
            case AnalizadorLexico.KW_INICIO:
                return "KW_INICIO";
            case AnalizadorLexico.KW_CUANDO:
                return "KW_CUANDO";
            case AnalizadorLexico.KW_SINO:
                return "KW_SINO";
            case AnalizadorLexico.KW_LOOP:
                return "KW_LOOP";
            case AnalizadorLexico.KW_NUM:
                return "KW_NUM";
            case AnalizadorLexico.KW_DEC:
                return "KW_DEC";
            case AnalizadorLexico.KW_TEXT:
                return "KW_TEXT";
            case AnalizadorLexico.KW_IMPRIMIR:
                return "KW_IMPRIMIR";
            case AnalizadorLexico.KW_RETORNAR:
                return "KW_RETORNAR";
            case AnalizadorLexico.IDENTIFICADOR:
                return "IDENTIFICADOR";
            case AnalizadorLexico.LIT_DECIMAL:
                return "LIT_DECIMAL";
            case AnalizadorLexico.LIT_ENTERO:
                return "LIT_ENTERO";
            case AnalizadorLexico.LIT_TEXT:
                return "LIT_TEXT";
            case AnalizadorLexico.LIT_BOOLEANO:
                return "LIT_BOOLEANO";
            case AnalizadorLexico.OP_SUMA:
                return "OP_SUMA";
            case AnalizadorLexico.OP_RESTA:
                return "OP_RESTA";
            case AnalizadorLexico.OP_MULT:
                return "OP_MULT";
            case AnalizadorLexico.OP_DIV:
                return "OP_DIV";
            case AnalizadorLexico.OP_MOD:
                return "OP_MOD";
            case AnalizadorLexico.OP_IGUAL:
                return "OP_IGUAL";
            case AnalizadorLexico.OP_DIFERENTE:
                return "OP_DIFERENTE";
            case AnalizadorLexico.OP_MAYOR_IGUAL:
                return "OP_MAYOR_IGUAL";
            case AnalizadorLexico.OP_MENOR_IGUAL:
                return "OP_MENOR_IGUAL";
            case AnalizadorLexico.OP_MAYOR:
                return "OP_MAYOR";
            case AnalizadorLexico.OP_MENOR:
                return "OP_MENOR";
            case AnalizadorLexico.OP_AND:
                return "OP_AND";
            case AnalizadorLexico.OP_OR:
                return "OP_OR";
            case AnalizadorLexico.OP_NOT:
                return "OP_NOT";
            case AnalizadorLexico.OP_ASIGNACION:
                return "OP_ASIGNACION";
            case AnalizadorLexico.DELIM_PAR_IZQ:
                return "DELIM_PAR_IZQ";
            case AnalizadorLexico.DELIM_PAR_DER:
                return "DELIM_PAR_DER";
            case AnalizadorLexico.DELIM_LLAVE_IZQ:
                return "DELIM_LLAVE_IZQ";
            case AnalizadorLexico.DELIM_LLAVE_DER:
                return "DELIM_LLAVE_DER";
            case AnalizadorLexico.DELIM_PUNTO_COMA:
                return "DELIM_PUNTO_COMA";
            case AnalizadorLexico.TOKEN_COMENT:
                return "TOKEN_COMENT";
            case AnalizadorLexico.TOKEN_ERROR:
                return "DESCONOCIDO";
            default:
                return "DESCONOCIDO";
        }
    }
}
