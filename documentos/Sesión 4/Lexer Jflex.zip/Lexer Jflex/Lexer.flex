import java.io.*;

%%
%class AnalizadorLexico
%public
%int
%line
%column

%{
  // Catálogo oficial de IDs de Tokens
  public static final int KW_INICIO = 1;
  public static final int KW_CUANDO = 2;
  public static final int KW_SINO = 3;
  public static final int KW_LOOP = 4;
  public static final int KW_NUM = 5;
  public static final int KW_DEC = 6;
  public static final int KW_TEXT = 7;
  public static final int KW_IMPRIMIR = 8;
  public static final int KW_RETORNAR = 9;

  public static final int IDENTIFICADOR = 10;

  public static final int LIT_DECIMAL = 11;
  public static final int LIT_ENTERO = 12;
  public static final int LIT_TEXT = 13;
  public static final int LIT_BOOLEANO = 14;

  public static final int OP_SUMA = 15;
  public static final int OP_RESTA = 16;
  public static final int OP_MULT = 17;
  public static final int OP_DIV = 18;
  public static final int OP_MOD = 19;

  public static final int OP_IGUAL = 20;
  public static final int OP_DIFERENTE = 21;
  public static final int OP_MAYOR_IGUAL = 22;
  public static final int OP_MENOR_IGUAL = 23;
  public static final int OP_MAYOR = 24;
  public static final int OP_MENOR = 25;

  public static final int OP_AND = 26;
  public static final int OP_OR = 27;
  public static final int OP_NOT = 28;

  public static final int OP_ASIGNACION = 29;

  public static final int DELIM_PAR_IZQ = 30;
  public static final int DELIM_PAR_DER = 31;
  public static final int DELIM_LLAVE_IZQ = 32;
  public static final int DELIM_LLAVE_DER = 33;
  public static final int DELIM_PUNTO_COMA = 34;

  public static final int TOKEN_COMENT = 35;
  public static final int TOKEN_ERROR = -2;

  public int getLine() { return yyline + 1; }
  public int getColumn() { return yycolumn + 1; }
%}

%%
/* Palabras Reservadas */
"inicio"               { return KW_INICIO; }
"cuando"               { return KW_CUANDO; }
"sino"                 { return KW_SINO; }
"loop"                 { return KW_LOOP; }
"num"                  { return KW_NUM; }
"dec"                  { return KW_DEC; }
"text"                 { return KW_TEXT; }
"imprimir"             { return KW_IMPRIMIR; }
"retornar"             { return KW_RETORNAR; }

/* Literales Booleanos (Prioridad sobre identificadores) */
"verdadero"|"falso"    { return LIT_BOOLEANO; }

/* Identificadores */
[_a-zA-Z][_a-zA-Z0-9]* { return IDENTIFICADOR; }

/* Literales Numéricos (Decimal primero para evitar truncado entero) */
[+-]?[0-9]+\.[0-9]+    { return LIT_DECIMAL; }
[+-]?[0-9]+            { return LIT_ENTERO; }

/* Literales de Texto (Strings) */
\"[^\"]*\"             { return LIT_TEXT; }

/* Operadores Relacionales Compuestos y Simples */
"=="                   { return OP_IGUAL; }
"!="                   { return OP_DIFERENTE; }
">="                   { return OP_MAYOR_IGUAL; }
"<="                   { return OP_MENOR_IGUAL; }
">"                    { return OP_MAYOR; }
"<"                    { return OP_MENOR; }

/* Operadores Lógicos */
"&&"                   { return OP_AND; }
"||"                   { return OP_OR; }
"!"                    { return OP_NOT; }

/* Asignación Simple */
"="                    { return OP_ASIGNACION; }

/* Operadores Aritméticos */
"+"                    { return OP_SUMA; }
"-"                    { return OP_RESTA; }
"*"                    { return OP_MULT; }
"/"                    { return OP_DIV; }
"%"                    { return OP_MOD; }

/* Delimitadores Estándar */
"("                    { return DELIM_PAR_IZQ; }
")"                    { return DELIM_PAR_DER; }
"{"                    { return DELIM_LLAVE_IZQ; }
"}"                    { return DELIM_LLAVE_DER; }
";"                    { return DELIM_PUNTO_COMA; }

/* Comentarios Personalizados */
"%%"[^%]*"%%"          { return TOKEN_COMENT; }

/* Espacios en blanco e ignorados */
[ \t\r\n]+             { /* Ignorar */ }

/* Error Léxico */
.                      { return TOKEN_ERROR; }
