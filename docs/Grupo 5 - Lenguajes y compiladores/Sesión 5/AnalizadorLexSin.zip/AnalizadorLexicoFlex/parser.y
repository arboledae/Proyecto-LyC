%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int yylex();
extern int yyparse();
extern FILE *yyin;
extern int yylineno; // Para reportar la línea del error

void yyerror(const char *s);

// Helper para validar la extensión del archivo
int ends_with_g5z80(const char *filename) {
    int len = strlen(filename);
    if (len < 6) return 0;
    const char *ext = filename + len - 6;
    return (ext[0] == '.' &&
            (ext[1] == 'g' || ext[1] == 'G') &&
            (ext[2] == '5') &&
            (ext[3] == 'z' || ext[3] == 'Z') &&
            (ext[4] == '8') &&
            (ext[5] == '0'));
}
%}

/* Declaración de los tipos de datos que Flex enviará en yylval */
%union {
    int entero;
    char* str;
}

/* Declaración de Tokens con sus nombres específicos */
%token KW_INICIO KW_CUANDO KW_SINO KW_LOOP
%token KW_NUM KW_DEC KW_TEXT
%token KW_IMPRIMIR KW_RETORNAR
%token OP_ASIGNACION OP_SUMA OP_RESTA OP_MULT OP_DIV OP_MOD
%token OP_IGUAL OP_DIFERENTE OP_MAYOR OP_MENOR
%token OP_MAYOR_IGUAL OP_MENOR_IGUAL
%token OP_AND OP_OR OP_NOT
%token DELIM_PAR_IZQ DELIM_PAR_DER
%token DELIM_LLAVE_IZQ DELIM_LLAVE_DER DELIM_PUNTO_COMA
%token TOKEN_COMENT TOKEN_ERROR

/* Tipos semánticos para tokens de valor (declarados directamente con tipo) */
%token <str> IDENTIFICADOR
%token <str> LIT_TEXT
%token <str> LIT_DECIMAL
%token <entero> LIT_ENTERO
%token <entero> LIT_BOOLEANO

/* Precedencia de operadores para evitar conflictos Shift/Reduce y establecer asociatividad */
%left OP_OR
%left OP_AND
%left OP_IGUAL OP_DIFERENTE OP_MAYOR OP_MENOR OP_MAYOR_IGUAL OP_MENOR_IGUAL
%left OP_SUMA OP_RESTA
%left OP_MULT OP_DIV OP_MOD
%right OP_NOT

/* Regla inicial del analizador */
%start programa

%%

programa:
    KW_INICIO DELIM_LLAVE_IZQ sentencias DELIM_LLAVE_DER { 
        printf("\n[Sintactico] >>> REDUCCION: programa completo (inicio { ... }) verificado con exito.\n"); 
    }
    ;

sentencias:
      sentencia sentencias {
          printf("[Sintactico] >>> REDUCCION: sentencias consecutivas procesadas.\n");
      }
    | /* vacio */
    ;

sentencia:
      declaracion DELIM_PUNTO_COMA { 
          printf("[Sintactico] >>> REDUCCION: Sentencia DECLARACION en linea %d completa.\n", yylineno); 
      }
    | asignacion DELIM_PUNTO_COMA   { 
          printf("[Sintactico] >>> REDUCCION: Sentencia ASIGNACION en linea %d completa.\n", yylineno); 
      }
    | condicional             { 
          printf("[Sintactico] >>> REDUCCION: Estructura CONDICIONAL completa en linea %d.\n", yylineno); 
      }
    | ciclo                   { 
          printf("[Sintactico] >>> REDUCCION: Estructura CICLO (loop) completa en linea %d.\n", yylineno); 
      }
    | impresion DELIM_PUNTO_COMA    { 
          printf("[Sintactico] >>> REDUCCION: Sentencia IMPRESION en linea %d completa.\n", yylineno); 
      }
    | retorno DELIM_PUNTO_COMA      { 
          printf("[Sintactico] >>> REDUCCION: Sentencia RETORNO en linea %d completa.\n", yylineno); 
      }
    ;

declaracion:
      tipo IDENTIFICADOR OP_ASIGNACION expresion {
          printf("[Sintactico] Declaracion e inicializacion: Variable '%s' asignada a una expresion en linea %d.\n", $2, yylineno);
      }
    | tipo IDENTIFICADOR {
          printf("[Sintactico] Declaracion simple: Variable '%s' sin inicializar en linea %d.\n", $2, yylineno);
      }
    ;

asignacion:
      IDENTIFICADOR OP_ASIGNACION expresion {
          printf("[Sintactico] Asignacion: Variable '%s' toma un nuevo valor en linea %d.\n", $1, yylineno);
      }
    ;

condicional:
      KW_CUANDO DELIM_PAR_IZQ condicion DELIM_PAR_DER DELIM_LLAVE_IZQ sentencias DELIM_LLAVE_DER {
          printf("[Sintactico] Bifurcacion condicional: Bloque 'cuando' analizado en linea %d.\n", yylineno);
      }
    | KW_CUANDO DELIM_PAR_IZQ condicion DELIM_PAR_DER DELIM_LLAVE_IZQ sentencias DELIM_LLAVE_DER KW_SINO DELIM_LLAVE_IZQ sentencias DELIM_LLAVE_DER {
          printf("[Sintactico] Bifurcacion condicional: Bloques 'cuando' y 'sino' analizados en linea %d.\n", yylineno);
      }
    ;

ciclo:
      KW_LOOP DELIM_PAR_IZQ condicion DELIM_PAR_DER DELIM_LLAVE_IZQ sentencias DELIM_LLAVE_DER {
          printf("[Sintactico] Bucle: Estructura 'loop' analizada en linea %d.\n", yylineno);
      }
    ;

impresion:
      KW_IMPRIMIR DELIM_PAR_IZQ expresion DELIM_PAR_DER {
          printf("[Sintactico] Llamado a funcion: impresion de expresion en linea %d.\n", yylineno);
      }
    ;

retorno:
      KW_RETORNAR expresion {
          printf("[Sintactico] Control: retorno con valor en linea %d.\n", yylineno);
      }
    | KW_RETORNAR {
          printf("[Sintactico] Control: retorno vacio en linea %d.\n", yylineno);
      }
    ;

condicion:
      expresion operador_rel expresion {
          printf("[Sintactico] Expresion Relacional: comparando dos expresiones en linea %d.\n", yylineno);
      }
    | OP_NOT condicion {
          printf("[Sintactico] Expresion Logica: NOT en linea %d.\n", yylineno);
      }
    | condicion OP_AND condicion {
          printf("[Sintactico] Expresion Logica: AND en linea %d.\n", yylineno);
      }
    | condicion OP_OR condicion {
          printf("[Sintactico] Expresion Logica: OR en linea %d.\n", yylineno);
      }
    | LIT_BOOLEANO {
          printf("[Sintactico] Expresion Relacional: literal booleano (%d) en linea %d.\n", $1, yylineno);
      }
    ;

operador_rel:
      OP_MAYOR       { printf("  -> Operador relacional: >\n"); }
    | OP_MENOR       { printf("  -> Operador relacional: <\n"); }
    | OP_MAYOR_IGUAL { printf("  -> Operador relacional: >=\n"); }
    | OP_MENOR_IGUAL { printf("  -> Operador relacional: <=\n"); }
    | OP_IGUAL       { printf("  -> Operador relacional: ==\n"); }
    | OP_DIFERENTE   { printf("  -> Operador relacional: !=\n"); }
    ;

expresion:
      expresion OP_SUMA expresion          { printf("  -> Operacion aritmetica: Suma (+)\n"); }
    | expresion OP_RESTA expresion         { printf("  -> Operacion aritmetica: Resta (-)\n"); }
    | expresion OP_MULT expresion          { printf("  -> Operacion aritmetica: Multiplicacion (*)\n"); }
    | expresion OP_DIV expresion           { printf("  -> Operacion aritmetica: Division (/)\n"); }
    | expresion OP_MOD expresion           { printf("  -> Operacion aritmetica: Modulo (%%)\n"); }
    | DELIM_PAR_IZQ expresion DELIM_PAR_DER     { printf("  -> Expresion entre parentesis (...)\n"); }
    | LIT_ENTERO                           { printf("  -> Expresion: Numero entero literal (%d)\n", $1); }
    | LIT_DECIMAL                          { printf("  -> Expresion: Numero decimal literal '%s'\n", $1); }
    | LIT_TEXT                             { printf("  -> Expresion: Cadena literal '%s'\n", $1); }
    | LIT_BOOLEANO                         { printf("  -> Expresion: Literal booleano (%d)\n", $1); }
    | IDENTIFICADOR                        { printf("  -> Expresion: Variable/Identificador '%s'\n", $1); }
    ;

tipo:
      KW_NUM  { printf("  -> Tipo de dato: num\n"); }
    | KW_DEC  { printf("  -> Tipo de dato: dec\n"); }
    | KW_TEXT { printf("  -> Tipo de dato: text\n"); }
    ;

%%

/* Función para manejar errores de sintaxis */
void yyerror(const char *s) {
    fprintf(stderr, "\n[ERROR SINTACTICO] Linea %d: %s\n\n", yylineno, s);
}

/* Función principal que arranca el compilador */
int main(int argc, char **argv) {
    if (argc > 1) {
        if (!ends_with_g5z80(argv[1])) {
            fprintf(stderr, "\n[ERROR DE EXTENSION] El compilador solo acepta archivos con extension '.g5z80'.\n");
            fprintf(stderr, "Ejemplo de uso: .\\compilador.exe ejemplo1.g5z80\n\n");
            return 1;
        }

        yyin = fopen(argv[1], "r");
        if (!yyin) {
            perror(argv[1]);
            return 1;
        }
        printf("\n==================================================\n");
        printf("Iniciando analisis de: %s\n", argv[1]);
        printf("==================================================\n\n");
    } else {
        printf("Por favor ingresa un archivo de texto con extension '.g5z80'.\n");
        printf("Ejemplo: .\\compilador.exe ejemplo1.g5z80\n");
        return 1;
    }
    
    // Iniciar analisis
    if (yyparse() == 0) {
        printf("\n==================================================\n");
        printf("ANALISIS SINTACTICO COMPLETADO EXITOSAMENTE\n");
        printf("==================================================\n");
    } else {
        printf("\n==================================================\n");
        printf("ANALISIS CONCLUIDO CON ERRORES SINTACTICOS\n");
        printf("==================================================\n");
    }
    
    fclose(yyin);
    return 0;
}
