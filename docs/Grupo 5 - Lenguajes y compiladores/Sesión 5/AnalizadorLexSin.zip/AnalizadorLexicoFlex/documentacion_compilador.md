# Documentación Técnica del Compilador (Front-End) para Z80

Esta documentación describe en detalle la arquitectura, la gramática y el flujo de compilación desarrollados hasta el momento para tu lenguaje de programación de alto nivel que compilará al microprocesador **Zilog Z80**.

---

## 1. Arquitectura General del Front-End

El frontend de un compilador se encarga de analizar el código fuente escrito por el programador y verificar que sea correcto antes de traducirlo. Está compuesto por dos partes principales:

```mermaid
graph TD
    A[Código Fuente .g5z80] -->|Flujo de Caracteres| B(Analizador Léxico - Flex)
    B -->|Tokens: yylex| C(Analizador Sintáctico - Bison)
    C -->|Verificación y Árbol de Sintaxis| D[Resultado: Exito / Error]
```

1. **Analizador Léxico (Lexer - Flex)**: Lee el archivo de texto de izquierda a derecha (carácter por carácter) y agrupa los caracteres en categorías lógicas llamadas **Tokens** (ej. palabras clave, números, operadores).
2. **Analizador Sintáctico (Parser - Bison)**: Toma la secuencia de tokens provista por el lexer y comprueba si respeta las reglas de la gramática del lenguaje (como la estructura de un bucle `loop` o de un condicional `cuando`).

---

## 2. Validación de Extensión (`.g5z80`)

Para dar identidad y orden a los archivos de código fuente de tu lenguaje, el compilador realiza una **validación estricta de la extensión del archivo** en su función principal (`main` de `parser.y`):

- **Extensión requerida**: `.g5z80` (no distingue entre mayúsculas y minúsculas: acepta `.g5z80`, `.G5Z80`, etc.).
- **Comportamiento**: Si intentas compilar un archivo con otra extensión (ej. `.txt`), el compilador lanzará un error de extensión explícito y detendrá el análisis de forma segura:
  ```text
  [ERROR DE EXTENSION] El compilador solo acepta archivos con extension '.g5z80'.
  Ejemplo de uso: .\compilador.exe ejemplo1.g5z80
  ```

---

## 3. Listado Oficial de Tokens

El compilador ha sido configurado para utilizar la siguiente lista oficial de tokens definidos por ti:

| Categoría | Tokens en el Parser | Lexema Asociado (Ejemplo) |
|---|---|---|
| **Palabras Clave (Keywords)** | `KW_INICIO`, `KW_CUANDO`, `KW_SINO`, `KW_LOOP`, `KW_NUM`, `KW_DEC`, `KW_TEXT`, `KW_IMPRIMIR`, `KW_RETORNAR` | `inicio`, `cuando`, `sino`, `loop`, `num`, `dec`, `text`, `imprimir`, `retornar` |
| **Identificadores** | `IDENTIFICADOR` | `x`, `resultado`, `mi_variable` |
| **Literales** | `LIT_ENTERO`, `LIT_DECIMAL`, `LIT_TEXT`, `LIT_BOOLEANO` | `10`, `12.5`, `"El valor es mayor"`, `verdadero`, `falso` |
| **Operadores Aritméticos** | `OP_ASIGNACION`, `OP_SUMA`, `OP_RESTA`, `OP_MULT`, `OP_DIV`, `OP_MOD` | `=`, `+`, `-`, `*`, `/`, `%` |
| **Comparadores** | `OP_IGUAL`, `OP_DIFERENTE`, `OP_MAYOR`, `OP_MENOR`, `OP_MAYOR_IGUAL`, `OP_MENOR_IGUAL` | `==`, `!=`, `>`, `<`, `>=`, `<=` |
| **Operadores Lógicos** | `OP_AND`, `OP_OR`, `OP_NOT` | `&&`, `||`, `!` |
| **Delimitadores** | `DELIM_PAR_IZQ`, `DELIM_PAR_DER`, `DELIM_LLAVE_IZQ`, `DELIM_LLAVE_DER`, `DELIM_PUNTO_COMA` | `(`, `)`, `{`, `}`, `;` |
| **Auxiliares** | `TOKEN_COMENT`, `TOKEN_ERROR` | `%% comentario %%`, cualquier carácter no permitido |

---

## 4. El Analizador Léxico ([lexer.l](file:///c:/Users/steve/OneDrive/Desktop/Lenguajes%20y%20Compiladores/AnalizadorLexicoFlex/lexer.l))

El analizador léxico está escrito en **Flex**. Lee el código de tu archivo `.g5z80`, reporta cada token en la consola detallando la línea y tipo, y pasa el ID del token correspondiente al parser.

### Reporte Detallado en Tiempo Real (Consola)
Al compilar y ejecutar, el Lexer genera mensajes de traza como:
- `[Lexico] Linea 2: Tipo de dato 'num'`
- `[Lexico] Linea 10: Operador OP_SUMA (+)`
- `[Lexico] Linea 15: Literal booleano 'verdadero'`

---

## 5. El Analizador Sintáctico ([parser.y](file:///c:/Users/steve/OneDrive/Desktop/Lenguajes%20y%20Compiladores/AnalizadorLexicoFlex/parser.y))

El analizador sintáctico está escrito en **Bison** y define la gramática formal del compilador.

### Gramática y Precedencia de Operadores
El parser soporta una gramática BNF rica. Las reglas de precedencia se definieron para evitar ambigüedades en expresiones matemáticas y lógicas:
```yacc
%left OP_OR
%left OP_AND
%left OP_IGUAL OP_DIFERENTE OP_MAYOR OP_MENOR OP_MAYOR_IGUAL OP_MENOR_IGUAL
%left OP_SUMA OP_RESTA
%left OP_MULT OP_DIV OP_MOD
%right OP_NOT
```

Esto garantiza que `!` se evalúe antes que `&&`, y que `*` / `/` / `%` se evalúen antes que las sumas y restas.

### Reporte Detallado de Reducciones (Parser)
A medida que se procesa el código, el Parser detalla el proceso interno imprimiendo las **Reducciones** (las estructuras sintácticas formadas con éxito):
- `[Sintactico] >>> REDUCCION: Sentencia DECLARACION en linea 2 completa.`
- `[Sintactico] >>> REDUCCION: Estructura CONDICIONAL completa en linea 13.`
- `[Sintactico] >>> REDUCCION: programa completo (inicio { ... }) verificado con exito.`

---

## 6. Control y Aborto de Errores

El compilador reporta errores sintácticos indicando la línea exacta donde ocurrieron y realiza una terminación inmediata:

1. **Uso de `yylineno`**: Flex realiza un conteo automático de las líneas del archivo fuente. Cuando ocurre un error sintáctico, el parser lee este valor y reporta con precisión en qué número de línea se originó el error.
2. **Aborto inmediato**: Si el programador comete un error sintáctico (ej. `num y = ;` o un carácter inválido), el compilador reporta `[ERROR SINTACTICO]`, aborta la compilación inmediatamente para evitar propagar errores y concluye con el mensaje `ANALISIS CONCLUIDO CON ERRORES SINTACTICOS`.

---

## 7. El Flujo de Compilación y Ejecución

Para compilar el compilador en Windows, ejecuta:
```powershell
.\compilar.bat
```

### Ejecutar Análisis sobre archivos del Lenguaje:

- **Ejemplo correcto**:
  ```powershell
  .\compilador.exe ejemplo1.g5z80
  ```
- **Ejemplo con errores**:
  ```powershell
  .\compilador.exe ejemplo_con_error.g5z80
  ```
