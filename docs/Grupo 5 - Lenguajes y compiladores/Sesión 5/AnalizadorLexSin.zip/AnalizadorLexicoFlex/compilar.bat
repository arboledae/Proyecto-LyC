@echo off
echo Generando archivos de Bison...
bison -d parser.y
if %ERRORLEVEL% neq 0 (
    echo Error al ejecutar Bison.
    pause
    exit /b %ERRORLEVEL%
)

echo Generando archivos de Flex...
flex lexer.l
if %ERRORLEVEL% neq 0 (
    echo Error al ejecutar Flex.
    pause
    exit /b %ERRORLEVEL%
)

echo Compilando con GCC...
gcc parser.tab.c lex.yy.c -o compilador.exe
if %ERRORLEVEL% neq 0 (
    echo Error al compilar con GCC.
    pause
    exit /b %ERRORLEVEL%
)

echo Proceso completado exitosamente. Se ha generado 'compilador.exe'.
pause
