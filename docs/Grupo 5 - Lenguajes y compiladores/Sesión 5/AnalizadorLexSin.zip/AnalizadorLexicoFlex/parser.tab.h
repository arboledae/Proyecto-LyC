/* A Bison parser, made by GNU Bison 2.7.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2012 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     KW_INICIO = 258,
     KW_CUANDO = 259,
     KW_SINO = 260,
     KW_LOOP = 261,
     KW_NUM = 262,
     KW_DEC = 263,
     KW_TEXT = 264,
     KW_IMPRIMIR = 265,
     KW_RETORNAR = 266,
     OP_ASIGNACION = 267,
     OP_SUMA = 268,
     OP_RESTA = 269,
     OP_MULT = 270,
     OP_DIV = 271,
     OP_MOD = 272,
     OP_IGUAL = 273,
     OP_DIFERENTE = 274,
     OP_MAYOR = 275,
     OP_MENOR = 276,
     OP_MAYOR_IGUAL = 277,
     OP_MENOR_IGUAL = 278,
     OP_AND = 279,
     OP_OR = 280,
     OP_NOT = 281,
     DELIM_PAR_IZQ = 282,
     DELIM_PAR_DER = 283,
     DELIM_LLAVE_IZQ = 284,
     DELIM_LLAVE_DER = 285,
     DELIM_PUNTO_COMA = 286,
     TOKEN_COMENT = 287,
     TOKEN_ERROR = 288,
     IDENTIFICADOR = 289,
     LIT_TEXT = 290,
     LIT_DECIMAL = 291,
     LIT_ENTERO = 292,
     LIT_BOOLEANO = 293
   };
#endif


#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{
/* Line 2058 of yacc.c  */
#line 28 "parser.y"

    int entero;
    char* str;


/* Line 2058 of yacc.c  */
#line 101 "parser.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */

#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
